from django.contrib import admin
from .models import NewSletter,ApplyCommitteeMembers,ApplyForSpeaker,ContactInformation,OnlineRegistration,Subscribe
# Register your models here.


admin.site.register(NewSletter)
admin.site.register(ApplyCommitteeMembers)
admin.site.register(ApplyForSpeaker)
admin.site.register(ContactInformation)
admin.site.register(OnlineRegistration)
admin.site.register(Subscribe)

