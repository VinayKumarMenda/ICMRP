from django.shortcuts import render,redirect
from .forms import NewSletterForm,ApplyCommitteeMembersForm,ApplyForSpeakerForm,ContactInformationForm,OnlineRegistrationForm,SubscribeForm

# Create your views here.


def index(request):
    if request.method=='POST':
        post=NewSletterForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=NewSletterForm()
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'index.html')


def aboutcollege(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'aboutcollege.html')
def aboutconference(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'aboutconference.html')
def aboutorganizer(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'aboutorganizer.html')


def applycommittee(request):
    if request.method=='POST':
        post=ApplyCommitteeMembersForm(request.POST,request.FILES)
        if post.is_valid():
            post.save()
        else:
            post=ApplyCommitteeMembersForm()
    
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'applycommittee.html')


def applyforspeaker(request):
    if request.method=='POST':
        post=ApplyForSpeakerForm(request.POST,request.FILES)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=ApplyForSpeakerForm()
    
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'applyforspeaker.html')


def awardcategories(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'awardcategories.html')
def conferenceguidelines(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'conferenceguidelines.html')
def conferenceregistration(request):
    
    if request.method=='POST':
        post=OnlineRegistrationForm(request.POST,request.FILES)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=OnlineRegistrationForm(request.POST,request.FILES)
            
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    
    return render(request,'conferenceregistration.html')


def contact(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'contact.html')
def datesreminder(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'datesreminder.html')
def eligibilitycommitte(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'eligibilitycommitte.html')
def journalfaq(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'journalfaq.html')
def keynote(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'keynote.html')
def organisingcommittee(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'organisingcommittee.html')
def papersubmission(request):
    
    if request.method=='POST':
        post=ContactInformationForm(request.POST,request.FILES)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=ContactInformationForm()
    
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    
    # if request.method=='POST':
    #     post=ConferenceDetailsForm(request.POST,request.FILES)
    #     if post.is_valid():
    #         post.save()
    #         return redirect('index')
    #     else:
    #         post=ConferenceDetailsForm()
    
    
    return render(request,'papersubmission.html')
def pastconferencespeakers(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'pastconferencespeakers.html')
def plagiarismpolicy(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'plagiarismpolicy.html')
def posterpresentors(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'posterpresentors.html')
def presentationguide(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'presentationguide.html')
def publicationopportunity(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'publicationopportunity.html')
def registrationfaq(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'registrationfaq.html')
def sessions(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'sessions.html')
def submissionguidelines(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'submissionguidelines.html')
def venue(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'venue.html')
def virtualpresentors(request):
    if request.method=='POST':
        post=SubscribeForm(request.POST)
        if post.is_valid():
            post.save()
            return redirect('index')
        else:
            post=SubscribeForm(request.POST)
    return render(request,'virtualpresentors.html')


