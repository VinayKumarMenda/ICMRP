from django.db import models

# Create your models here.


class NewSletter(models.Model):
    name=models.CharField(max_length=200)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    country=models.CharField(max_length=200)
    about_conference=models.CharField(max_length=200)
    
    def __str__(self):
        return f'{self.name} NewSletter'


class ApplyCommitteeMembers(models.Model):
    
    title=models.CharField(max_length=20)
    name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    member_category=models.CharField(max_length=200)
    organisation=models.CharField(max_length=200)
    qualification=models.CharField(max_length=200)
    department=models.CharField(max_length=200)
    specialisation=models.CharField(max_length=200)
    research_area=models.CharField(max_length=200)
    country=models.CharField(max_length=200)
    iferp=models.CharField(max_length=200)
    publications=models.CharField(max_length=20)
    books_published=models.CharField(max_length=20)
    review_journals=models.CharField(max_length=500)
    description=models.CharField(max_length=1000)
    c_v=models.FileField((""), upload_to='files', max_length=100)
    def __str__(self):
        return f'{self.name} Committe Member'
    

class ApplyForSpeaker(models.Model):
    title=models.CharField(max_length=10)
    name=models.CharField(max_length=200)
    phone=models.CharField(max_length=20)
    email=models.CharField(max_length=100)
    employer=models.CharField(max_length=200)
    personal_url=models.CharField(max_length=200)
    country=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    city=models.CharField(max_length=100)
    postal_code=models.CharField(max_length=100)
    topic=models.CharField(max_length=200)
    linkedin_profile=models.CharField(max_length=200)
    recent_talk_slides=models.CharField(max_length=200)
    lecture_video_url=models.CharField(max_length=200)
    c_v=models.FileField(upload_to='files')
    recent_talks=models.FileField(upload_to='files')
    def __str__(self):
        return f'{self.name} Speaker'
    
    
    
class ContactInformation(models.Model):
    author_name=models.CharField(max_length=200)
    co_author_name=models.CharField(max_length=200)
    email=models.CharField(max_length=100)
    country=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    whatsapp_no=models.CharField(max_length=20)
    paper_title=models.CharField(max_length=500)
    
    # Conference Details
    
    conference_name=models.CharField(max_length=500)
    department=models.CharField(max_length=100)
    university=models.CharField(max_length=200)
    designation=models.CharField(max_length=200)
    presentation_type=models.CharField(max_length=200)
    conference_date=models.CharField(max_length=20)
    conference_city=models.CharField(max_length=100)
    message=models.TextField()
    file=models.FileField(upload_to='files')
    about_conference=models.CharField(max_length=100)
    
    def __str__(self):
        return f'{self.author_name} {self.conference_name}'
    

class OnlineRegistration(models.Model):
    title=models.CharField(max_length=20)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    name_for_certificate=models.CharField(max_length=200)
    dob=models.CharField(max_length=20)
    nationality=models.CharField(max_length=200)
    department=models.CharField(max_length=100)
    institution=models.CharField(max_length=200)
    address=models.CharField(max_length=500)
    post_code=models.CharField(max_length=50)
    email=models.EmailField()
    phone=models.IntegerField()
    country=models.CharField(max_length=100)
    participant_category=models.CharField(max_length=200)
    presentation_category=models.CharField(max_length=200)
    price=models.FloatField()
    about_conference=models.CharField(max_length=200)
    
    def __str__(self):
        return self.first_name


class Subscribe(models.Model):
    email=models.EmailField()
    
    def __str__(self):
        return self.email