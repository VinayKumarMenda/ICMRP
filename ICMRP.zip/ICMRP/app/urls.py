from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
    path('',index,name='index'),
    path('aboutconference',aboutconference,name='aboutconference'),
    path('aboutcollege',aboutcollege,name='aboutcollege'),
    path('aboutorganizer',aboutorganizer,name='aboutorganizer'),
    path('applycommittee',applycommittee,name='applycommittee'),
    path('applyforspeaker',applyforspeaker,name='applyforspeaker'),
    path('awardcategories',awardcategories,name='awardcategories'),
    path('conferenceguidelines',conferenceguidelines,name='conferenceguidelines'),
    path('conferenceregistration',conferenceregistration,name='conferenceregistration'),
    path('contact',contact,name='contact'),
    path('datesreminder',datesreminder,name='datesreminder'),
    path('eligibilitycommitte',eligibilitycommitte,name='eligibilitycommitte'),
    path('journalfaq',journalfaq,name='journalfaq'),
    path('keynote',keynote,name='keynote'),
    path('organisingcommittee',organisingcommittee,name='organisingcommittee'),
    path('papersubmission',papersubmission,name='papersubmission'),
    path('pastconferencespeakers',pastconferencespeakers,name='pastconferencespeakers'),
    path('plagiarismpolicy',plagiarismpolicy,name='plagiarismpolicy'),
    path('posterpresentors',posterpresentors,name='posterpresentors'),
    path('presentationguide',presentationguide,name='presentationguide'),
    path('publicationopportunity',publicationopportunity,name='publicationopportunity'),
    path('registrationfaq',registrationfaq,name='registrationfaq'),
    path('sessions',sessions,name='sessions'),
    path('submissionguidelines',submissionguidelines,name='submissionguidelines'),
    path('venue',venue,name='venue'),
    path('virtualpresentors',virtualpresentors,name='virtualpresentors'),
    
]