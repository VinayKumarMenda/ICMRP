from django import forms
from .models import NewSletter,ApplyCommitteeMembers,ApplyForSpeaker,ContactInformation,OnlineRegistration,Subscribe




class NewSletterForm(forms.ModelForm):
    class Meta:
        model =NewSletter 
        fields = ['name','email','phone','country','about_conference']
        
        
class ApplyCommitteeMembersForm(forms.ModelForm):
    class Meta:
        model =ApplyCommitteeMembers
        fields = ['title','name','last_name','email','phone','member_category','organisation','qualification','department',
                  'specialisation','research_area','country','iferp',
        'publications','books_published','review_journals','description','c_v']
        
        
class ApplyForSpeakerForm(forms.ModelForm):
    class Meta:
        model=ApplyForSpeaker
        fields=['title','name','phone','email','employer','personal_url',
                'country','state','city','postal_code','topic','linkedin_profile',
                'recent_talk_slides','lecture_video_url','c_v','recent_talks']
        
class ContactInformationForm(forms.ModelForm):
    class Meta:
        model =ContactInformation
        fields = ['author_name','co_author_name','email','country','phone','whatsapp_no',
                  'paper_title','conference_name','department','university','designation',
                  'presentation_type',
                  'conference_date','conference_city','message','about_conference']
        
class OnlineRegistrationForm(forms.ModelForm):
    class Meta:
        model =OnlineRegistration
        fields = ['title','first_name','last_name','name_for_certificate','dob','nationality',
                  'department','institution','address','post_code','email','phone','country',
                  'participant_category','price','about_conference']
        
class SubscribeForm(forms.ModelForm):
    class Meta:
        model=Subscribe
        fields=['email']