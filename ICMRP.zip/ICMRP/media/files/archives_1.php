<!doctype html>
<html lang="en">
  <?php include("admin/config.php") ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TRPUB ONLINE</title>
    <link rel="icon" type="image/x-icon" href="images/icon.png">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" integrity="sha384-Rx+T1VzGupg4BHQYs2gCW9It+akI2MM/mndMCy36UVfodzcJcF0GGLxZIzObiEfa" crossorigin="anonymous"></script>
  </head>
  <body class="bg-light">
    
    <!-- ---------- -->
    <div class="container">
        <div class="row align-items-center bg-white">
            <div class="col-md-2">
                <img src="images/Thomson-Ryberg-Publications.png" alt="" class="img-fluid">
            </div>
            <div class="col-md-7">
                <div class="text-start">
                    <!-- <img src="images/TEXT.png" alt="" class="img-fluid"> -->
                    <h3 class="main_title">International Journal of Ophthalmology and Refractive Surgery</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-end">
                    <p>
                        <span>
                            <a href=""><img src="images/faa.png" class="img-fluid" alt=""></a>
                            <a href=""><img src="images/innn.png" class="img-fluid" alt=""></a>
                            <a href=""><img src="images/pppp.png" class="img-fluid" alt=""></a>

                        </span>
                    </p>
                    <p class="addr">
                        <!-- <span class="fw-bold">Call</span>: +91 8790520044 <br>
                        <span class="fw-bold">Email ID:</span>: trpub.online@gmail.com -->
                    </p>
                    
                </div>
            </div>
           
        </div>

        <nav class="navbar navbar-expand-lg p-0">
            <div class="container-fluid">
             
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item">
                    <a class="nav-link active text-white" aria-current="page" href="index.html">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="about-us.html">About Us</a>
                  </li>
                 <li class="nav-item">
                    <a class="nav-link text-white" href="index.html">A-z Journals</a>
                  </li>
                </ul>
               
              </div>
            </div>
          </nav>
            <!-- --------- -->
            <div class="row bg-white">
                <div class="col-md-2">
                    <!-- <img src="images/top.png" class="img-fluid"  alt=""> -->
                    <h6 class="text-center py-3 inf">
                      <!-- <i class="fa-solid fa-circle-info "></i> -->
                      <i class="fa-solid fa-circle-info fa-fade fs-3 text-primary"></i> <span class="fw-bold">Information Menu</span>
                    </h6>
                    <nav class="nav flex-column">
                      <a class="side-nv-link nav-link active" aria-current="page" href="#">About Us</a>
                      <a class="side-nv-link nav-link" href="editorial-board.html">Editorial Board</a>
                      <a class="side-nv-link nav-link" href="#">Current Issue</a>
                      <a class="side-nv-link nav-link" href="archives.php">Archives</a>
                      <a class="side-nv-link nav-link" href="">Publication Ethics</a>
                      <a class="side-nv-link nav-link" href="">Conferences</a>
                      <a class="side-nv-link nav-link" href="#">Special Issues</a>
                      
                      <!-- <a class="side-nv-link nav-link" href="Term_and_conditions.html">Term and Conditions</a> -->
                      <a class="side-nv-link nav-link" href="contact.html">Contact Us</a>
                  </nav>
                      <div>
                        <a href="">
                            <img src="images/acc.png" class="img-fluid mt-2 bg-light"  alt="">
                        </a>

                        <p class="text-center py-3" style="border: 3px solid rgb(94, 91, 91);">
                            <a href="" class="text-decoration-none fw-bold">Online <br> Manuscript Submission</a>
                        </p>
                      </div>
                </div>
                <div class="col-md-10 py-3">
                  <!-- ===================== -->
                  <div class="card mb-3 card1" style="max-width: 600px;">
                      <div class="row g-0">
                          <div class="col-md-3 text-center py-3">
                              <img src="../images/world.jpg" class="img-fluid" alt="world">
                          </div>
                          <div class="col-md-9">
                          <div class="card-body">
                                  
                                  <p class="card-text p1 fw-bold">Published By : <span class="span2 fw-bold">Thomson & Ryberg Publications</span></p>
                                  <p class="card-text p1 fw-bold">Editor-in-Chief : <span class="span2 fw-bold">Dr. C. Babou</span></p>
                                  <p class="card-text p1 fw-bold">Frequency : <span class="span2 fw-bold">Quarterly</span></p>
                                  <p class="card-text p1 fw-bold">ISSN : <span class="span2 fw-bold">2456-1649</span></p>
                                  <a href="submit-manuscript.html" class="btn btn-outline-secondary btn-sm" title="open access publication">Online Submission</a>
                              </div>
                            </div>
                          </div>
                    </div>
                  <!-- ===================== -->
                  <h5 class="border-bottom p-2"><span >Archieves</span> <span class="title"></span></h5>
                    
                  <table class="table table-bordered table-hover table-striped">
	<tbody>
		<tr class="table-bordered table-dark">
			<th class="table-head text-center">S.No</th>
			<th class="table-head text-center">Month</th>
			<th class="table-head text-center">Year</th>
			<th class="table-head text-center">No. of Volume &amp; Issues</th>
		</tr>
	</tbody>
	<tbody>
	<?php
                     $sql = "select * from vol_iss ORDER BY id DESC";
                     $query = mysqli_query($db , $sql );
                     $rows = mysqli_num_rows( $query);
                     $count = 0;
                     if($rows){
                        while($result=mysqli_fetch_assoc($query))
                           {
                              ?>

		<tr class="text-center">
			<td><?php echo  ++$count ?></td>
			<td><?php echo $result['month'] ?></td>
            <td><?php echo $result['year'] ?></td>
            <td><a href="previous-issue.php?id=<?php echo $result['id'] ?>"><?php echo $result['category'] ?></a></td>
		</tr>
		<?php
                     }
               }
               else{
                     ?>
                        <tr>
                           <td colspan = "4">No Records Found</td>
                        </tr>
                     <?php
               }
               ?>
		
		
	</tbody>
</table>
                   
                </div>

                <!-- footer -->
                <div class="col-md-12 footer">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="text-white ftr"><span class="fw-bold">Copyright</span> &copy;2023 www.trpubonline.com All Rights Reserved</p>
                        </div>
                        <div class="col-md-6">
                            <p class="text-white ftr"><span class="fw-bold">Email id:</span> trpub.online@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>

          <!--==========  -->
          
    </div>
    <!-- ============= -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  <!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>
</html>